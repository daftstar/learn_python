# s = 'abc'
# s.capitalize
# print(s.capitalize())

str1 = 'exterminate!'
str2 = 'number one - the larch'


str1
# print(str1.upper())